pip install yt-dlp
# ffmpeg must also be installed!
python youtube_to_amv.py